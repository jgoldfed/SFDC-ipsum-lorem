<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Constante",
    "DESC" => "Generates a column of data that has repeated values for multiple rows. You can make all rows have the same value, or assign the same value to groups of them."
);

$L["help_1"] = "Dit gegevenstype kunt u het genereren van een kolom met gegevens die waarden is het herhalen van rij tot rij. Hier volgt een aantal voorbeelden om u een idee van hoe dit werkt.";
$L["help_2"] = "Als u wilt de waarde \"1\" voor elke rij geven, kunt u \"1\" in de Waarde (n) veld en elke waarde (> 0) in de Loop veld Aantal.";
$L["help_3"] = "Als u wilt 100 rijen van de string \"Male\", gevolgd door 100 rijen van de string \"Vrouw\" en herhaal, kunt u \"100\" in de Loop veld Aantal en \"Man | Vrouw\", in de Waarde (n) veld.";
$L["help_4"] = "Als u wilt 5 rijen van 1 willen tot en met 10, voert u \"5\" voor de Loop veld Aantal en \"1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10\" in het Waarde (n) veld.";
$L["help_5"] = "Probeer knutselen rond met het. Je krijgt het idee.";
$L["incomplete_fields"] = "De Constant gegevenstype moet hebben de constanten te worden ingevoerd in de waarde (n) veld. Please fix de volgende rijen:";
$L["invalid_loop_counts"] = "Geef cijfers voor constante lus tellen velden. Please fix de volgende rij (en):";
$L["loop_count"] = "Loop count:";
$L["values"] = "Waarde (n):";

