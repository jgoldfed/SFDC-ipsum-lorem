<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 1",
    "DESC" => "Track 1 contains the cardholder's name as well as account number and other discretionary data. The credit card may be of any type (Visa, Mastercard, etc)."
);
