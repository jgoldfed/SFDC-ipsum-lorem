<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Ville",
    "DESC" => "Displays a random city, or if data is available, displays a city for the appropriate country/region."
);
