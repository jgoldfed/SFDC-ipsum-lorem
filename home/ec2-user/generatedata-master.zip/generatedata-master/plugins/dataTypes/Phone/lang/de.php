<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Telefon / Fax",
    "DESC" => "Generates a random phone/fax number in a variety of formats for different countries/regions."
);

$L["australia"] = "Australien";
$L["different_formats"] = "Unterschiedliche Formate";
$L["example_1"] = "Kanada (1)";
$L["example_2"] = "Kanada (2)";
$L["france"] = "Frankreich";
$L["germany"] = "Deutschland";
$L["help_text1"] = "Was Text Sie in den Optionen Textfeld eingeben werden verwendet, um Telefonnummern zu generieren. Kapital <b>X</b>'s zu einer Zufallszahl zwischen 1 und 9 umgewandelt werden; Kleinbuchstaben <b>x</b>'s zu einer Zufallszahl umgewandelt werden zwischen 0 und 9.";
$L["help_text2"] = "Wählen Sie einen der Werte im Beispiel Dropdown für einige Ideen. Denken Sie daran: alles andere als die <b>X</b> und <b>x</b>-Zeichen übrig unbekehrt.";
$L["help_text3"] = "Wie bei vielen der anderen Datentypen zu generieren Telefonnummern in mehreren Formaten trennen Sie sie mit einem Rohr | Charakter.";
$L["incomplete_fields"] = "The Phone / Fax Datentyp haben muss das Format eingetragen im Options Textfeld. Bitte beheben Sie die folgenden Zeilen:";
$L["japan"] = "Japan";
$L["uk"] = "Vereinigtes Königreich";
