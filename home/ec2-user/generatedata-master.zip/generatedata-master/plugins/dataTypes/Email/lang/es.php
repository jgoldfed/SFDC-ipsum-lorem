<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Correo electrónico",
    "DESC" => "Generates a random email address."
);

