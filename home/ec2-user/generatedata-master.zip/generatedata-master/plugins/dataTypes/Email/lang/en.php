<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Email",
    "DESC" => "Generates a random email address."
);
