<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "E-mail",
    "DESC" => "Generates a random email address."
);
