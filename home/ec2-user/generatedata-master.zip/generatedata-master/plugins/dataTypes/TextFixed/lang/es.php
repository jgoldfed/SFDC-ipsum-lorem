<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Número fijo de palabras",
    "DESC" => "Esta opción genera un número fijo palabras al azar, sacadas del texto estándar en Latín lorem ipsum."
);

$L["TextFixed_generate"] = "Generar";
$L["TextFixed_help"] = "Esta opción genera un número fijo palabras al azar, sacadas del texto estándar en Latín <a href=&quot;http://en.wikipedia.org/wiki/Lorem_ipsum&quot; target=&quot;_blank&quot;>lorem ipsum</a>.";
$L["TextFixed_words"] = "palabras";
$L["incomplete_fields"] = "Por favor, introduce el número de palabras que quieres general para todos los campos Número fijo de palabras. Revisa las filas:";
