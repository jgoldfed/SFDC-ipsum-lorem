<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Adresse",
    "DESC" => "Generates random street addresses."
);

$L["ap_num"] = "Appartement ";
$L["name"] = "Adresse";
$L["po_box"] = "CP";
$L["street_types"] = "Rue,Route,Chemin,Rd.,Ave,Av.,Avenue,Impasse";
