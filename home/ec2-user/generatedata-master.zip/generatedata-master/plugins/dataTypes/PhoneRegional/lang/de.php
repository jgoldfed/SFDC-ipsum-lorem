<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Telefon / Fax, Regional",
    "DESC" => "Dieser Datentyp versucht, eine Telefonnummer in einem geeigneten Format für die Reihe von Daten zu generieren. Wenn es ein unbekanntes Land trifft, erzeugt es einen Standard-Rufnummer im Format (xxx) xxx-xxxx."
);
