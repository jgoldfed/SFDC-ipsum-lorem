<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Land",
    "DESC" => "Generates a random country name, with the option to limit the subset to those countries entered via the interface."
);

$L["limit_results"] = "Beschränken Ländern zu den oben ausgewählten";
