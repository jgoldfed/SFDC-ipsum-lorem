<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "País",
    "DESC" => "Generates a random country name, with the option to limit the subset to those countries entered via the interface."
);

$L["limit_results"] = "Limitar los países a los elegidos más arriba";
