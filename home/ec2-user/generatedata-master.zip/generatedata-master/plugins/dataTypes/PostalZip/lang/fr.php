<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Code Postal";

$L["help_text"] = "Génère un code postal aléatoire. Pour un meilleur contrôle, utilisez le type de données Alphanumérique.";
