<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Postal / Zip";
$L["help_text"] = "Genereert een willekeurig zip of postcode. Voor meer controle gebruikt u de alpha-numeriek gegevenstype optie.";
