<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Código postal";
$L["help_text"] = "Genera un código postal aleatorio. Para mayor control, utilice la opción de tipo de dato alfanumérico.";
