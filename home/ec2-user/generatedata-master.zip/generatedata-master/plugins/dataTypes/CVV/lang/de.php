<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Erzeugt eine Zufalls CVV-Nummer von <b>111</b> bis <b>999</b>."
);
