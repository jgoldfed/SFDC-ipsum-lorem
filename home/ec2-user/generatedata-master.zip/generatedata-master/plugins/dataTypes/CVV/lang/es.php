<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Genera un número de tarjeta de crédito CVV azar <b>111</b>-<b>999</b>."
);
