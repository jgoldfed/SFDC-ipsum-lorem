<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Latitude / Longitude",
    "DESC" => "This data type generates a random latitude and/or longitude. If both are selected, it displays both separated by a comma."
);

$L["latitude"] = "Latitude";
$L["longitude"] = "Longitude";
