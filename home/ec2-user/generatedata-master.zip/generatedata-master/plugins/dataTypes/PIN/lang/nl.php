<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Genereert een willekeurig creditcard pincode van <b>1111</b> om <b>9999</b>."
);
