<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Erzeugt eine Zufallskreditkarte PIN-Nummer von <b>1111</b> bis <b>9999</b>."
);
