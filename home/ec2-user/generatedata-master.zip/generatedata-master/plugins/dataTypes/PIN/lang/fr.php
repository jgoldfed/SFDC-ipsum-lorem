<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Génère un code PIN aléatoire de carte de crédit de <b>1111</b> à <b>9999</b>."
);
