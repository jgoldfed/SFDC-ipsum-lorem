<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Genera un número PIN de la tarjeta de crédito azar de <b>1111</b> a <b>9999</b>."
);
