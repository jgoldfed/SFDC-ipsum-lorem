<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Aantal Range",
    "DESC" => "Dit genereert willekeurig een getal tussen de waarden die u opgeeft. Beide velden kunt u negatieve getallen in te voeren."
);

$L["and"] = "en";
$L["between"] = "Tussen";
$L["incomplete_fields"] = "Vul het nummer bereik (laagste en hoogste aantallen) voor de volgende rijen:";
