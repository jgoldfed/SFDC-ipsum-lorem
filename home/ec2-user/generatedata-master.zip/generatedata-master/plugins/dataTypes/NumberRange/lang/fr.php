<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Plage de numéros",
    "DESC" => "Cela génère au hasard un nombre entre les valeurs que vous spécifiez. Les deux champs vous permettent d'entrer des nombres négatifs."
);

$L["and"] = "et";
$L["between"] = "Entre";
$L["incomplete_fields"] = "Précisez un minimum et un maximum pour les lignes suivantes:";
