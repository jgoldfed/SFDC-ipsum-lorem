<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Distribución normal",
    "DESC" => "Generates random normally distributed values with a customizable mean and standard deviation"
);

$L["mean"] = "Media";
$L["standard_deviation"] = "Desviación estándar";
$L["incomplete_fields"] = "Los campos Media y Sigma son obligatorios para todas las filas de Distribución normal. Por favor, corrija las siguientes filas:";
