<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Normaal Distributie",
    "DESC" => "Generates random normally distributed values with a customizable mean and standard deviation"
);

$L["incomplete_fields"] = "Les champs moyens et Sigma sont nécessaires pour toutes les lignes de distribution normale. S'il vous plaît corriger les lignes suivantes:";
$L["mean"] = "Signifier";
$L["standard_deviation"] = "Écart type";
