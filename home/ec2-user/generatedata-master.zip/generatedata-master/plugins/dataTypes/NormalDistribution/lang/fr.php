<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Distribution Normale",
    "DESC" => "Generates random normally distributed values with a customizable mean and standard deviation"
);

$L["incomplete_fields"] = "Les champs 'Moyenne' et 'Ecart type' sont nécessaires pour toutes les lignes de distribution normale. Corrigez les lignes suivantes:";
$L["mean"] = "Moyenne";
$L["standard_deviation"] = "Écart type";
