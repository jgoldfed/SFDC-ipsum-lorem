<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 2",
    "DESC" => "Track 2 contains the cardholder's account, encrypted PIN, plus other discretionary data. The credit card may be of any type (Visa, Mastercard, etc)."
);
