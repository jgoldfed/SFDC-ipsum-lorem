<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 2",
    "DESC" => "Track 2 enthält Konto des Karteninhabers, verschlüsselte PIN sowie weitere Ermessens Daten. Die Kreditkarte kann von jedem Typ (Visa, Mastercard, etc.) sein."
);
