<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Vennootschap",
    "DESC" => "Dit gegevenstype genereert een willekeurige naam, bestaande uit een Lorem ipsum woord en een passende achtervoegsel, zoals <i>Dolor Inc</i>, of <i>Convallis Limited</i>."
);
