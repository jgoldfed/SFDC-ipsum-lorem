<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Company",
    "DESC" => "Generates a random company name, comprised of a lorem ipsum word and an appropriate suffix, like Dolor Inc., or Convallis Limited."
);
