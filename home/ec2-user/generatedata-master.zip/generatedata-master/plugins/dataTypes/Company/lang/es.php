<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Empresa",
    "DESC" => "Este tipo de dato genera un nombre de empresa al azar, generado a partir de una palabra <i>lorem ipsum</i> y de un sufijo apropiado como <i>Dolor Inc.</i>, o <i>Convallis Limited</i>."
);
