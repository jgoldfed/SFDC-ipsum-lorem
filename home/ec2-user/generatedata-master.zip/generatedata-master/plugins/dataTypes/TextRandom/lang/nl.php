<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Random Number of Words",
    "DESC" => "Deze optie genereert een willekeurig aantal woorden - het totale aantal binnen het bereik dat u opgeeft (inclusief)."
);

$L["generate"] = "Voortbrengen";
$L["help"] = "Deze optie genereert een willekeurig aantal woorden - het totale aantal binnen het bereik dat u opgeeft (inclusief). Net als bij de vaste nummer optie, worden de woorden trok de standaard Lorem ipsum Latijnse tekst.";
$L["incomplete_fields"] = "Voer de minimum en maximum aantal woorden in dat u wilt genereren voor alle willekeurig aantal woorden velden. Zie rijen:";
$L["start_with_lipsum"] = "Begin met \"Lorem Ipsum...\"";
$L["to"] = "naar";
$L["words"] = "tekst";
