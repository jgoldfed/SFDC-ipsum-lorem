<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Número aleatorio de palabras",
    "DESC" => "Esta opción genera un número aleatorio de palabras, el número total dentro del rango que especifiques (inclusivo)."
);

$L["incomplete_fields"] = "Por favor, introduce el número mínimo y máximo de palabras que quieres generar para todos los campos Número aleatorio de palabras. Revise las filas:";
$L["start_with_lipsum"] = "Start with \"Lorem Ipsum...\"";
$L["generate"] = "Generar";
$L["to"] = "a";
$L["words"] = "palabras";
$L["help"] = "Esta opción genera un número aleatorio de palabras, el número total dentro del rango que especifiques (inclusivo). Al igual que con la opción de número Fijo, las palabras son sacadas del texto estándar en Latín <i>lorem ipsum</i>.";
