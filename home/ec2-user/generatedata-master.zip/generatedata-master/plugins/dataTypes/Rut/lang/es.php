<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "RUT chileno",
    "DESC" => "Genera un RUT / RUN Número de Identificación Nacional de Chile ."
);

$L["different_formats"] = "Formatos diferentes";
$L["incomplete_fields"] = "El tipo de dato Rut necesita tener seleccionado el campo ejemplo. Por favor arreglar las siguientes filas: ";
$L["rut_default"] = "Por defecto";
$L["only_number"] = "S&oacute;lo Rut";
$L["only_digit"] = "S&oacute;lo d&iacute;gito verificador";

$L["thousands_separator"] = "Separador de miles";
$L["digit_uppercase"] = "D&iacute;gito en may&uacute;sculas";
$L["remove_dash"] = "Excluir gui&oacute;n";
