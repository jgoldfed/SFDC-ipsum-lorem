<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "CSV";

$L["delimiter_chars"] = "Delimiter char (s)";
$L["eol_char"] = "Zeilenendezeichen";
$L["validation_no_delimiter"] = "Bitte geben Sie ein Trennzeichen für die CSV-Export-Typ.";
